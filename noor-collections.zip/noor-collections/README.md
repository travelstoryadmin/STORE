# Noor Collections

Next.js App Router starter matching the approved Noor Collections homepage mockup.

## Demo admin
Username: `admin`
Password: `admin123`

After login, the Add Product button appears. Products are stored in browser localStorage for this prototype.

## WhatsApp
Change `wa` in `app/page.tsx` to your WhatsApp number in international format without `+`.
